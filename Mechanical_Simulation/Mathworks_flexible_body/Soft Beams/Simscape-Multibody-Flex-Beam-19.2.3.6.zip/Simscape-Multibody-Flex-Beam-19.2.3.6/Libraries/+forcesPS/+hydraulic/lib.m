function lib( libInfo )
% Customize library
% Copyright 2005-2019 The MathWorks, Inc

libInfo.Name = 'Hydraulic';
end
